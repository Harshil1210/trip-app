import Joi from "joi";

export const loginValidation = Joi.object({
  password: Joi.string()
    .required()
    .messages({ "any.required": "password is required" }),
  email: Joi.string().email().required().lowercase().messages({
    "any.required": "email is required",
    "string.email": "email format is invalid",
  }),
});

export const registerValidation = Joi.object({
  password: Joi.string().required(),
  email: Joi.string()
    .email({ minDomainSegments: 2, tlds: { allow: ["com", "net"] } })
    .required()
    .lowercase()
    .messages({
      "any.required": "email is required",
      "string.email": "email format is invalid",
      "string.lowercase": "email must be in lowercase",
    }),
  name: Joi.string().min(3).required().messages({
    "any.required": "name is required",
    "string.min": "name must contain atleast 4 characters",
  }),
});
