/** @type {import('next').NextConfig} */
const nextConfig = {
    images : {
        domains: ['roadtrippers.com'],
    }
};

export default nextConfig;
