"use client";
import React from "react";
import { useForm } from "react-hook-form";
import { getError } from "@/Libraries/error";
import Link from "next/link";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useRouter } from "next/navigation";
import axios from "axios";

const Login = () => {
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data: any) => {
    try {
      const response = await axios.post("/api/login", {
        email: data.email,
        password: data.password,
      });
      console.log(response.data)
      if(response.status == 200){
        localStorage.setItem("user",JSON.stringify(response.data))
        toast.success("Login successful!");
        router.push("/trips")
      } else {
        toast.info("Email or password is incorrect")
      }
    } catch (error) {
      toast.error(getError(error));
    }
  };

  return (
    <>
      <section className=" bg-gray-900 w-screen min-h-screen">
        <div className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
          <div className="w-full  rounded-lg shadow border md:mt-0 sm:max-w-md xl:p-0 bg-gray-800 border-gray-700">
            <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
              <div>
                <div>
                  <ToastContainer />
                </div>
              </div>
              <h1 className="text-xl font-bold leading-tight tracking-tight  md:text-2xl text-white">
                Log In to Your Account
              </h1>
              <form
                onSubmit={handleSubmit(onSubmit)}
                className="space-y-4 md:space-y-6"
                action="#"
              >
                <div>
                  <label
                    htmlFor="email"
                    className="block mb-2 text-sm font-medium  text-white"
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    {...register("email", {
                      required: "Please enter email",
                      pattern: {
                        value:
                          /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
                        message: "Please enter a valid email",
                      },
                    })}
                    id="email"
                    autoFocus
                    className=" border  text-sm rounded-lg  block w-full p-2.5 bg-gray-700 border-gray-600 placeholder-gray-400 text-white focus:ring-blue-500 focus:border-blue-500"
                  />
                  {errors.email && (
                    <div className="text-red-500">Email is not valid</div>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="password"
                    className="block mb-2 text-sm font-medium  text-white"
                  >
                    Password
                  </label>
                  <input
                    type="password"
                    {...register("password", {
                      required: "Please enter password",
                      minLength: {
                        value: 6,
                        message: "Password must be at least 6 characters long",
                      },
                    })}
                    id="password"
                    autoComplete="on"
                    className=" border  text-sm rounded-lg  block w-full p-2.5 bg-gray-700 border-gray-600 placeholder-gray-400 text-white focus:ring-blue-500 focus:border-blue-500"
                  />
                  {errors.password && (
                    <div className="text-red-500">Password is not valid</div>
                  )}
                </div>
                <button
                  type="submit"
                  className="w-full text-white  focus:ring-4 focus:outline-none  font-medium rounded-lg text-sm px-5 py-2.5 text-center bg-blue-600 hover:bg-blue-700 focus:ring-blue-800"
                >
                  Login
                </button>
                <p className="text-sm font-light  text-center text-gray-400">
                  Dont have an account?{" "}
                  <Link href="/user/signup" className="text-blue-500">
                    SignUp here
                  </Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Login;
