import UserModel from "@/Models/user";
import db from "@/Libraries/Db";
import bcryptjs from "bcryptjs";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { email, password } = await req.json();

  await db.connect();

  try {
    // Check if user with provided email exists
    const user = await UserModel.findOne({ email });

    if (!user) {
      return NextResponse.json({
        message: "Email or password is incorrect"
      }, { status: 404 });
    }

    // Verify password
    const passwordMatch = await bcryptjs.compare(password, user.password);

    if (!passwordMatch) {
      return NextResponse.json({
        message: "Invalid password. Please try again.",
      }, { status: 401 });
    }

    // Password is correct, generate JWT token or session management here if needed

    return NextResponse.json({
      message: "Login successful",
      _id: user._id,
      name: user.name,
      email: user.email,
      // Add additional user data as needed
    }, { status: 200 });

  } catch (error : any) {
    console.error("Login error:", error.message);
    return NextResponse.json({
      message: "Internal server error",
    }, { status: 500 });

  } finally {
    await db.disconnect();
  }
}
