/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useEffect, useState } from "react";
import { Feature, Map, View } from "ol";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector.js";
import { OSM } from "ol/source";
import LineString from "ol/geom/LineString.js";
import VectorSource from "ol/source/Vector.js";
import * as olProj from "ol/proj";
import Style from "ol/style/Style";
import Stroke from "ol/style/Stroke";
import { Trip as trip } from "../page";

const Trip = ({ params }: { params: { tripId: string } }) => {
  const [trip, setTrip] = useState<trip>();
  const trips = localStorage.getItem("trips");
  useEffect(() => {
    if (trips) {
      let tripstoJSON = JSON.parse(trips);
      const trip = tripstoJSON.filter(
        (trip: trip) => trip._id === params.tripId
      );
      setTrip(trip[0]);
    }
  }, [params.tripId, trips]);

  useEffect(() => {
  
    const coords = [
      23.0225,
      72.5714, // Ahmedabad coordinate 1 (longitude, latitude)
      23.0305,
      72.5803, // Intermediate coordinate 1
      23.0342,
      72.5841, // Intermediate coordinate 2
      23.0467,
      72.5889, // Ahmedabad coordinate 2 (longitude, latitude)
    ];

    let path = [];
    for (let i = 0; i < coords.length; i += 2) {
      path.push(olProj.fromLonLat([coords[i + 1], coords[i]])); // Note the order of lon-lat
    }

    const lineString = new LineString(path);
    const feature = new Feature({
      geometry: lineString,
    });

    const source2 = new VectorSource();
    source2.addFeature(feature);

    const vector = new VectorLayer({
      source: source2,
      style: new Style({
        stroke: new Stroke({
          color: "red",
          width: 3,
          lineCap: "round",
          lineJoin: "round",
          lineDash: [],
          lineDashOffset: 0,
          miterLimit: 10,
        }),
      }),
    });

    const map = new Map({
      layers: [
        new TileLayer({
          source: new OSM(),
        }),
        vector,
      ],
      target: "map",
      view: new View({
        center: olProj.fromLonLat([72.5799, 23.0225]), // Centered on Ahmedabad
        zoom: 15, // Adjust zoom level as needed
      }),
    });
  }, []);

  return (
    <div className="min-h-screen  p-10">
      <h1 className="lg:text-6xl md:text-4xl sm:text-xl font-bold text-center m-5 mb-10">
        {trip?.name}
      </h1>
      <h1 className="text-lg font-bold">Route : </h1>
      <div className="map h-96 w-full bg-blue-200 mb-5" id=""></div>

      <h1 className="text-lg font-bold">Destinations : </h1>
      <div className="grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-1 gap-8">
        {trip?.destinations.map((dest) => (
          <>
            <div key={trip._id} className="shadow-2xl	">
              <img src={dest.imageUrl} alt="" className="h-full w-full" />
              <h3 className="text-2xl font-bold text-center my-3">
                {" "}
                {dest.name}
              </h3>
              <h3 className="text-lg">{dest.description}</h3>
            </div>
          </>
        ))}
      </div>
    </div>
  );
};

export default Trip;
