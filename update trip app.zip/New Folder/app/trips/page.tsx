/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useRouter } from "next/navigation";
export interface Destination {
  name: string;
  description: string;
  location: {
    coordinates: [number, number];
  };
  imageUrl: string;
}

export interface Trip {
  _id: string;
  name: string;
  description: string;
  location: {
    coordinates: [number, number];
  };
  destinations: Destination[];
  image: string;
}

const Trips: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const router = useRouter()

  useEffect(() => {
    const fetchTrips = async () => {
      try {
        const response = await axios.get("/api/trips");
        localStorage.setItem("trips", JSON.stringify(response.data));
        setTrips(response.data);
      } catch (error) {
        console.error("Error fetching trips:", error);
      }
    };
    fetchTrips();
  }, []);

  return (
    <>
    <label htmlFor="gsearch">Search Google:</label>
  <input type="search" id="gsearch" name="gsearch" />
  <input type="submit"></input>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-20 ">
      {trips.map((trip) => (
        <div
          className="max-w-sm rounded overflow-hidden shadow-lg mx-auto mb-4"
          key={trip._id}
          onClick={() =>{console.log("clicked"), router.push(`trips/${trip._id}`)} }
        >
          <img className="w-full" src={`${trip.image}`} alt="" />
          <div className="px-6 py-4">
            <div className="font-bold text-xl mb-2">{trip.name}</div>
            <p className="text-gray-700 text-base">{trip.description}</p>
          </div>
        </div>
      ))}
    </div>
    </>
  );
};

export default Trips;
