import db from "@/Libraries/Db";
import Trip from "@/Models/trip";
import { NextRequest, NextResponse } from "next/server";

db.connect();

export async function POST(req: NextRequest, res: NextResponse) {
  const { name, description, location, destinations, image } = await req.json();
  try {
    const newTrip = new Trip({
      name,
      description,
      location,
      destinations,
      image,
    });
    const savedTrip = await newTrip.save();
    return NextResponse.json({ savedTrip }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 });
  }
}

export async function GET(req: NextRequest, res: NextResponse) {
  try {
    const trips = await Trip.find();
    return NextResponse.json(trips, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 });
  }
}