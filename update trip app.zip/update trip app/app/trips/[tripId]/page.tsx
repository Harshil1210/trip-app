/* eslint-disable @next/next/no-img-element */
"use client"
import React, { useEffect, useState } from "react";
import { Feature, Map, View } from "ol";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector.js";
import { OSM } from "ol/source";
import LineString from "ol/geom/LineString.js";
import VectorSource from "ol/source/Vector.js";
import * as olProj from "ol/proj";
import Style from "ol/style/Style";
import Stroke from "ol/style/Stroke";
import { Trip as trip } from "../page";

const Trip = ({ params }: { params: { tripId: string } }) => {

    const [trip,setTrip] = useState<trip>()
    const trips = localStorage.getItem("trips")
    const id = 1
    useEffect(() => {
         if (trips) {
           let tripstoJSON = JSON.parse(trips);
           const trip = tripstoJSON.filter(
             (trip: trip) => trip._id === params.tripId
           );
           setTrip(trip[0]);
         }
    },[params.tripId, trips])
   

    

    useEffect(() => {
      const coords = [
        23.0225,
        72.5714, // Ahmedabad coordinate 1 (longitude, latitude)
        23.0305,
        72.5803, // Intermediate coordinate 1
        23.0342,
        72.5841, // Intermediate coordinate 2
        23.0467,
        72.5889, // Ahmedabad coordinate 2 (longitude, latitude)
      ];

      let path = [];
      for (let i = 0; i < coords.length; i += 2) {
        path.push(olProj.fromLonLat([coords[i + 1], coords[i]])); // Note the order of lon-lat
      }

      const lineString = new LineString(path);
      const feature = new Feature({
        geometry: lineString,
      });

      const source2 = new VectorSource();
      source2.addFeature(feature);

      const vector = new VectorLayer({
        source: source2,
        style: new Style({
          stroke: new Stroke({
            color: "red",
            width: 3,
            lineCap: "round", 
            lineJoin: "round", 
            lineDash: [],
            lineDashOffset: 0,
            miterLimit: 10,
          }),
        }),
      });

      const map = new Map({
        layers: [
          new TileLayer({
            source: new OSM(),
          }),
          vector,
        ],
        target: "map",
        view: new View({
          center: olProj.fromLonLat([72.5799, 23.0225]), // Centered on Ahmedabad
          zoom: 15, // Adjust zoom level as needed
        }),
      });
    }, [id]);


        
        

  return (
    // <div className="h-auto w-auto">
    //   <h1 className="text-6xl font-bold text-center m-5 mb-10">{trip?.name}</h1>
    //   {/* <div className="map h-96 w-full " id="map" ></div> */}
    //   <div className="days mt-10  h-auto w-full">
    //     <h1>Day1</h1>
    //     <div className="day mt-3  flex h-72 w-full justify-between align-middle items-center">
    //       <div className="bg-red-500 h-5/6 w-96">
    //         <img
    //           src={trip?.destinations[0].imageUrl}
    //           style={{ width: "100%", height: "100%" }}
    //           alt=""
    //         />
    //       </div>
    //       <div className="bg-red-500  h-5/6 w-96">
    //         <img
    //           src={trip?.destinations[1].imageUrl}
    //           style={{ width: "100%", height: "100%" }}
    //           alt=""
    //         />
    //       </div>
    //       <div className="bg-red-500  h-5/6 w-96"></div>
    //       <div className="bg-red-500  h-5/6 w-96"></div>
    //     </div>
    //     <h1>Day2</h1>
    //     <div className="day mt-3  flex h-72 w-full justify-between align-middle items-center">
    //       <div className="bg-red-500 h-5/6 w-96"></div>
    //       <div className="bg-red-500  h-5/6 w-96"></div>
    //       <div className="bg-red-500  h-5/6 w-96"></div>
    //       <div className="bg-red-500  h-5/6 w-96"></div>
    //     </div>
    //   </div>
    // </div>
    <div className="bg-gray-50 dark:bg-gray-900 min-h-screen p-6">
    {/* Map Section */}
    {/* <div className="mb-6">
      <div id="map" className="w-full h-96 rounded-lg shadow-md"></div>
    </div> */}

    {/* Trip Details */}
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Trip Details</h2>

      {/* Day-wise details placeholder */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* {trip.days.map((day, index) => ( */}
          <div  className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Day </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400"></p>
            {/* Assuming you have images in your day object */}
            <div className="mt-2 grid grid-cols-2 gap-2">
              {/* {day.images.map((image, imgIndex) => ( */}
                <img
                src=""
                alt=""
                  // key={imgIndex}
                  // src={image.url}
                  // alt={`Day ${index + 1} Image ${imgIndex + 1}`}
                  className="w-full h-auto rounded-lg shadow-md"
                />
            
            </div>
          </div>
       
      </div>
    </div>
  </div>
  );
};

export default Trip;
