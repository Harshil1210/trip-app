import React from "react";
import Image from "next/image";

const TripLayout = ({ children }: { children: React.ReactNode }) => {
  return (
    <>
      <header className="bg-gray-50 dark:bg-gray-900 text-white text-left py-4 px-4">
        <h1 className="text-2xl font-bold">Travel Adventures</h1>
        <div className="fixed w-screen overflow-hidden -z-1 h-screen">
          <Image
            src="https://roadtrippers.com/wp-content/uploads/2024/04/Sunflowers.webp"
            alt=""
            layout="fill"
            objectFit="cover"
            quality={100}
          />
        </div>
      </header>
      <main>{children}</main>
    </>
  );
};

export default TripLayout;
