// models/Trip.js
import mongoose from "mongoose";

const { Schema } = mongoose;

const DestinationSchema = new Schema({
  name: { type: String, required: true },
  description: { type: String },
  location: {
    type: {
      type: String,
      default: "Point",
      enum: ["Point"],
    },
    coordinates: {
      type: [Number],
      required: true,
    },
  },
  imageUrl: { type: String },
});

const TripSchema = new Schema({
  name: { type: String, required: true },
  description: { type: String },
  location: {
    type: {
      type: String,
      default: "Point",
      enum: ["Point"],
    },
    coordinates: {
      type: [Number],
      required: true,
    },
  },
  destinations: {
    type: [DestinationSchema],
    required: true,
  },
  image: String,
});

const Trip = mongoose.models.Trip || mongoose.model("Trip", TripSchema);

export default Trip;
