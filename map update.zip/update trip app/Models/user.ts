import mongoose, { Schema } from "mongoose";

const UserSchema = new Schema(
  {
    id: Number,
    name: {
      type: String,
      required: [true, "Name is required"],
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
    },
    photo: String,
    password: {
      type: String,
      required: [true, "Please provide a password"],
      minLength: 8,
    },
  },
  { timestamps: true }
);

UserSchema.pre("save", async function (next) {
  var doc = this;
  if (!doc.isNew) {
    return next();
  }
  const count = await mongoose.model("User").countDocuments({});
  doc.id = count + 1;
});

const UserModel = mongoose.models?.User || mongoose.model("User", UserSchema);
export default UserModel;
