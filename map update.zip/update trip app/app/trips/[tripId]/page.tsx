/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useEffect, useState } from "react";
import { Feature, Map, View } from "ol";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector.js";
import { OSM } from "ol/source";
import LineString from "ol/geom/LineString.js";
import VectorSource from "ol/source/Vector.js";
import * as olProj from "ol/proj";
import Style from "ol/style/Style";
import Stroke from "ol/style/Stroke";
import { Trip as trip } from "../page";

const Trip = ({ params }: { params: { tripId: string } }) => {
  // const [trip, setTrip] = useState<any>();
  // const trips = localStorage.getItem("trips");
  // useEffect(() => {
  //   if (trips) {
  //     let tripstoJSON = JSON.parse(trips);
  //     const trip = tripstoJSON.filter(
  //       (trip: trip) => trip._id === params.tripId
  //     );
  //     setTrip(trip[0]);
  //   }
  // }, [params.tripId, trips]);

  const trip =  {
    "location": {
        "type": "Point",
        "coordinates": [
            10.7522,
            59.9139
        ]
    },
    "_id": "66745c99d023f8e5b971b9f7",
    "name": "Scandinavian Discovery",
    "description": "An exploration of Scandinavia's natural beauty and vibrant culture.",
    "days": [
        {
            "date": "2024-07-01T00:00:00.000Z",
            "destinations": [
                {
                    "location": {
                        "type": "Point",
                        "coordinates": [
                            12.589,
                            55.6794
                        ]
                    },
                    "name": "Nyhavn",
                    "description": "A 17th-century waterfront, canal, and entertainment district in Copenhagen, Denmark.",
                    "imageUrl": "https://example.com/nyhavn.jpg",
                    "_id": "66745c99d023f8e5b971b9f9"
                },
                {
                    "location": {
                        "type": "Point",
                        "coordinates": [
                            12.5683,
                            55.6737
                        ]
                    },
                    "name": "Tivoli Gardens",
                    "description": "One of the oldest amusement parks in the world and a landmark in Copenhagen, Denmark.",
                    "imageUrl": "https://example.com/tivoli.jpg",
                    "_id": "66745c99d023f8e5b971b9fa"
                }
            ],
            "notes": "Beginning the journey in Copenhagen, experiencing its historic charm.",
            "_id": "66745c99d023f8e5b971b9f8"
        },
        {
            "date": "2024-07-02T00:00:00.000Z",
            "destinations": [
                {
                    "location": {
                        "type": "Point",
                        "coordinates": [
                            18.0919,
                            59.3288
                        ]
                    },
                    "name": "Vasa Museum",
                    "description": "A maritime museum in Stockholm, Sweden, featuring the Vasa, a 17th-century warship.",
                    "imageUrl": "https://example.com/vasa.jpg",
                    "_id": "66745c99d023f8e5b971b9fc"
                },
                {
                    "location": {
                        "type": "Point",
                        "coordinates": [
                            18.0675,
                            59.325
                        ]
                    },
                    "name": "Gamla Stan",
                    "description": "The old town of Stockholm, Sweden, known for its medieval alleyways and historic buildings.",
                    "imageUrl": "https://example.com/gamla_stan.jpg",
                    "_id": "66745c99d023f8e5b971b9fd"
                }
            ],
            "notes": "Delving into Stockholm's maritime history and cultural heritage.",
            "_id": "66745c99d023f8e5b971b9fb"
        },
        {
            "date": "2024-07-03T00:00:00.000Z",
            "destinations": [
                {
                    "location": {
                        "type": "Point",
                        "coordinates": [
                            7.205,
                            62.1018
                        ]
                    },
                    "name": "Geirangerfjord",
                    "description": "A stunning fjord in Norway known for its deep blue waters and picturesque surrounding mountains.",
                    "imageUrl": "https://example.com/geirangerfjord.jpg",
                    "_id": "66745c99d023f8e5b971b9ff"
                },
                {
                    "location": {
                        "type": "Point",
                        "coordinates": [
                            5.3243,
                            60.3976
                        ]
                    },
                    "name": "Bergen Bryggen",
                    "description": "A historic wharf area in Bergen, Norway, known for its colorful wooden houses.",
                    "imageUrl": "https://example.com/bergen_bryggen.jpg",
                    "_id": "66745c99d023f8e5b971ba00"
                }
            ],
            "notes": "Cruising through Norway's majestic fjords and visiting charming Bergen.",
            "_id": "66745c99d023f8e5b971b9fe"
        }
    ],
    "image": "https://example.com/scandinavian_discovery.jpg",
    "__v": 0
}

  useEffect(() => {
    if (!trip) return;

    const coordinates = trip.days.flatMap((day : any) => day.destinations.map((dest : any) => dest.location.coordinates));
    let path = coordinates.map((coord : any) => olProj.fromLonLat([coord[0], coord[1]]));

    const lineString = new LineString(path);
    const feature = new Feature({
      geometry: lineString,
    });

    const source = new VectorSource();
    source.addFeature(feature);

    const vector = new VectorLayer({
      source: source,
      style: new Style({
        stroke: new Stroke({
          color: "red",
          width: 3,
          lineCap: "round",
          lineJoin: "round",
          lineDash: [],
          lineDashOffset: 0,
          miterLimit: 10,
        }),
      }),
    });

    const map = new Map({
      layers: [
        new TileLayer({
          source: new OSM(),
        }),
        vector,
      ],
      target: "map",
      view: new View({
        center: olProj.fromLonLat(trip.location.coordinates), // Center map on trip location
        zoom: 6,
      }),
    });

    return () => {
      map.setTarget(null || "");
    };
  }, [trip]);

  return (
    // <div className="min-h-screen p-10">
    //   <h1 className="lg:text-6xl md:text-4xl sm:text-xl font-bold text-center m-5 mb-10">
    //     {trip?.name}
    //   </h1>
    //   <h1 className="text-lg font-bold">Route : </h1>
    //   <div className="map h-96 w-full bg-blue-200 mb-5" id="map"></div>

    //   <h1 className="text-lg font-bold">Destinations : </h1>
    //   <div className="grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-1 gap-8">
    //     {trip?.destinations.map((dest) => (
    //       <div key={dest.name} className="shadow-2xl">
    //         <img src={dest.imageUrl} alt="" className="h-full w-full" />
    //         <h3 className="text-2xl font-bold text-center my-3">
    //           {dest.name}
    //         </h3>
    //         <h3 className="text-lg">{dest.description}</h3>
    //       </div>
    //     ))}
    //   </div>
    // </div>
    <div className="min-h-screen p-10">
    <h1 className="lg:text-6xl md:text-4xl sm:text-xl font-bold text-center m-5 mb-10">
      {trip.name}
    </h1>
    <h1 className="text-lg font-bold">Route:</h1>
    <div className="map h-96 w-full bg-blue-200 mb-5" id="map"></div>

    <h1 className="text-lg font-bold">Days:</h1>
    {trip.days.map((day : any, index : any) => (
      <div key={index} className="mb-8">
        <h2 className="text-xl font-bold">Day {index + 1}</h2>
        <p className="italic">{day.notes}</p>
        <div className="grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-1 gap-8 mt-4">
          {day.destinations.map((destination : any, idx : any) => (
            <div key={idx} className="shadow-2xl">
              <img src={destination.imageUrl} alt="" className="h-full w-full" />
              <h3 className="text-2xl font-bold text-center my-3">{destination.name}</h3>
              <p className="text-lg">{destination.description}</p>
            </div>
          ))}
        </div>
      </div>
    ))}
  </div>
  );
};

export default Trip;
