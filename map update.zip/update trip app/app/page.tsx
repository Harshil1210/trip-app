import Login from "./user/login/page";

export default function Home() {
  return (
    <>
      <Login />
    </>
  );
}
