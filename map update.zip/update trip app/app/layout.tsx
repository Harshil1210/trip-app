import type { Metadata } from "next";
import { Roboto_Mono, Poppins } from "next/font/google";
import "./globals.css";

const poppins = Poppins({
  weight: ["100", "300", "400", "500", "700"],
  subsets: ["latin"],
  variable: "--font-poppins",
});

const robotoMono = Roboto_Mono({
  weight: ["100", "200", "300", "400"],
  subsets: ["latin"],
  variable: "--font-roboto-mono",
});

export const metadata: Metadata = {
  title: "Trip-App",
  description: "App for trips",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`[${poppins.variable},${robotoMono.variable}] min-h-screen`}
      >
        {children}
      </body>
    </html>
  );
}
