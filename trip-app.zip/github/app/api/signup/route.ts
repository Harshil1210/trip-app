import UserModel from "@/Models/user";
import db from "@/Libraries/Db";
import bcryptjs from "bcryptjs";
import { registerValidation } from "@/Validations/userValidation";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { name, email, password } = await req.json();

  const { error } = registerValidation.validate(req.json());
  if (error) {
    NextResponse.json(
      { Error: `${error.details[0].message}` },
      { status: 400 }
    );
  }

  await db.connect();
  const existingUser = await UserModel.findOne({ email: email });

  if (existingUser) {
    return NextResponse.json({
      message: "User exists already",
    });
    // await db.disconnect();
  }

  const newUser = new UserModel({
    name,
    email,
    password: bcryptjs.hashSync(password),
  });

  const user = await newUser.save();

  // await db.disconnect();

  return NextResponse.json(
    {
      message: "Created user",
      _id: user._id,
      name: user.name,
      email: user.email,
    },
    { status: 200 }
  );
}
