import React from 'react'

const TripLayout = ({ children }: { children: React.ReactNode }) => {
  return (
    <>
      <header className="bg-black text-white text-left py-4 px-4">
        <h1 className="text-2xl font-bold">Travel Adventures</h1>
      </header>
      <main className='p-20'>{children}</main>
    </>
  );
};

export default TripLayout